package ajeffrey.teaching.minisoap;

public class SoapException extends RuntimeException {
    
    public SoapException (final String msg) {
	super (msg);
    }

}
