package ajeffrey.teaching.minisoap;

public interface Task {

    public void run (Executor exec);

}
