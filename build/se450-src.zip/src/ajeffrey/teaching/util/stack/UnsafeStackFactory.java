package ajeffrey.teaching.util.stack;

public interface UnsafeStackFactory {

    public UnsafeStack build ();

}
