package ajeffrey.teaching.util.buffer;

/**
 * An exception thrown when a buffer is full.
 * @author Alan Jeffrey
 * @version 1.0.1
 */
public class BufferFullException extends RuntimeException {
}
