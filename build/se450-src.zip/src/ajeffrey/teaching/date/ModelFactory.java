package ajeffrey.teaching.date;

public interface ModelFactory {

    public Model build ();

}
