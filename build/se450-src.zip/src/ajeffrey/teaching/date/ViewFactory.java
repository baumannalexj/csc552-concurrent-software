package ajeffrey.teaching.date;

public interface ViewFactory {

    public View build (Model model);

}
