package ajeffrey.teaching.hash2.client;

import ajeffrey.teaching.hash2.iface.Hash;

public interface GUIFactory {

    public GUI build (Hash hashTable);

}
